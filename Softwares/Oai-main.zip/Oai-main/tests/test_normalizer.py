from src.normalizer import Normalizer


def test_normalizer():
    """Test normalizer with sample command."""
    normalizer = Normalizer()
    text, context = normalizer.normalize_command("open youtube")

    print(text)
    print(context)


if __name__ == "__main__":
    test_normalizer()
