from src.planner import Planner


def test_planner():
    """Test planner with sample normalized command."""
    planner = Planner(api_key="test_key")

    normalized_command = "open youtube and search for python tutorials"
    context = {
        "keywords": ["open", "youtube", "search"],
        "preferences": {}
    }

    plan = planner.generate_plan(normalized_command, context)
    print(plan)


if __name__ == "__main__":
    test_planner()
