from src.validator import Validator


def test_validator():
    """Test validator with sample plan."""
    validator = Validator()

    plan = {
        "plan": [
            {"action": "open_browser", "parameters": {"url": "youtube.com"}}
        ]
    }

    print(validator.validate_plan(plan))


if __name__ == "__main__":
    test_validator()

