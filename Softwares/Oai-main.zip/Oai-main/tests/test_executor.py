from src.executor import Executor


def test_executor():
    """Test executor with sample plan."""
    executor = Executor()

    plan = {
        "plan": [
            {"action": "type_text", "parameters": {"text": "Hello, World!"}}
        ]
    }

    executor.execute_plan(plan)


if __name__ == "__main__":
    test_executor()
