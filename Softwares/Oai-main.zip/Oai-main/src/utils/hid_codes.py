def get_hid_code(action_type, *args):
    """Map high level action to HID command dictionaries.

    Args:
        action_type: Type of action to perform
        *args: Additional arguments depending on action type

    Returns:
        dict: HID command dictionary or None if action not recognized
    """
    if action_type == "GUI_LEFT":
        return {"type": "keyword", "key": "GUI_LEFT", "state": args[0]}

    elif action_type == "r":
        return {"type": "keyword", "key": "r", "state": args[0]}

    elif action_type == "enter":
        return {"type": "keyword", "key": "enter", "state": args[0]}

    elif action_type == "chrome":
        return {"type": "keyword_string", "text": "chrome"}

    elif action_type == "type":
        return {"type": "keyword_string", "text": args[0]}

    elif action_type == "mouse_click":
        return {
            "type": "mouse",
            "button": args[0],
            "x": args[1],
            "y": args[2]
        }

    return None
